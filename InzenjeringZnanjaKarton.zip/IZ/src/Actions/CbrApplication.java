package Actions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import model.DiseaseDesc;
import model.Osoba;
import ucm.gaia.jcolibri.casebase.LinealCaseBase;
import ucm.gaia.jcolibri.cbraplications.StandardCBRApplication;
import ucm.gaia.jcolibri.cbrcore.Attribute;
import ucm.gaia.jcolibri.cbrcore.CBRCase;
import ucm.gaia.jcolibri.cbrcore.CBRCaseBase;
import ucm.gaia.jcolibri.cbrcore.CBRQuery;
import ucm.gaia.jcolibri.cbrcore.Connector;
import ucm.gaia.jcolibri.exception.ExecutionException;
import ucm.gaia.jcolibri.method.retrieve.RetrievalResult;
import ucm.gaia.jcolibri.method.retrieve.NNretrieval.NNConfig;
import ucm.gaia.jcolibri.method.retrieve.NNretrieval.NNScoringMethod;
import ucm.gaia.jcolibri.method.retrieve.NNretrieval.similarity.global.Average;
import ucm.gaia.jcolibri.method.retrieve.NNretrieval.similarity.local.Equal;
import ucm.gaia.jcolibri.method.retrieve.selection.SelectCases;

public class CbrApplication implements StandardCBRApplication {
	private float prag;
	private int a=0;
	HashMap<String,Float>map = new HashMap<>();
	public static HashMap<String,Map<String,Float>> mapp=new HashMap<String,Map<String,Float>>();
	Connector _connector;  /** Connector object */
	CBRCaseBase _caseBase;  /** CaseBase object */

	NNConfig simConfig;  /** KNN configuration */
	
	public void configure() throws ExecutionException {
		_connector =  new CsvConnector();
		
		_caseBase = new LinealCaseBase();  // Create a Lineal case base for in-memory organization
		
		simConfig = new NNConfig(); // KNN configuration
		simConfig.setDescriptionSimFunction(new Average());  // global similarity function = average
	
		TableSimilarity ts = new TableSimilarity((Arrays.asList(new String[] {"blidness","double vision"})));
        ts.setSimilarity("blidness", "double vision", 0);
		
		 simConfig.addMapping(new Attribute("simptom", DiseaseDesc.class), new Equal()); 
		 simConfig.addMapping(new Attribute("godine", DiseaseDesc.class), new Equal());
		 simConfig.addMapping(new Attribute("rasa", DiseaseDesc.class), new Equal());
		 simConfig.addMapping(new Attribute("pol", DiseaseDesc.class), new Equal());
		 simConfig.addMapping(new Attribute("ime",DiseaseDesc.class), ts);
		// simConfig.addMapping(new Attribute("season", TravelDescription.class), new Equal());
		// simConfig.addMapping(new Attribute("accommodation", TravelDescription.class), new Equal());
		// simConfig.addMapping(new Attribute("hotel", TravelDescription.class), new Equal());

		// Equal - returns 1 if both individuals are equal, otherwise returns 0
		// Interval - returns the similarity of two number inside an interval: sim(x,y) = 1-(|x-y|/interval)
		// Threshold - returns 1 if the difference between two numbers is less than a threshold, 0 in the other case
		// EqualsStringIgnoreCase - returns 1 if both String are the same despite case letters, 0 in the other case
		// MaxString - returns a similarity value depending of the biggest substring that belong to both strings
		// EnumDistance - returns the similarity of two enum values as the their distance: sim(x,y) = |ord(x) - ord(y)|
		// EnumCyclicDistance - computes the similarity between two enum values as their cyclic distance
		// Table - uses a table to obtain the similarity between two values. Allowed values are Strings or Enums. The table is read from a text file.
		// TableSimilarity(List<String> values).setSimilarity(value1,value2,similarity) 
	}

	public void cycle(CBRQuery query) throws ExecutionException {
		Collection<RetrievalResult> eval = NNScoringMethod.evaluateSimilarity(_caseBase.getCases(), query, simConfig);
		eval = SelectCases.selectTopKRR(eval, 8);
		System.out.println("Retrieved cases:");
		for (RetrievalResult nse : eval) {
			String zasplit = nse.get_case().getDescription()+";"+nse.getEval();
		String []values = zasplit.split(";");
		if(a==0) {
			prag = Float.parseFloat(values[2]);
			map.put(values[0], Float.parseFloat(values[1]));
			a++;
		}
		else {
	
			if(prag==Float.parseFloat(values[2])) {
				System.out.println(nse.getEval());
				map.put(values[0], Float.parseFloat(values[1]));
			}
		}
		}
	
		for(String s:map.keySet()) {
			System.out.println(s +" "+ map.get(s));
		}
		mapp.put("blidness", map);

	}

	public void postCycle() throws ExecutionException {
		
	}

	public CBRCaseBase preCycle() throws ExecutionException {
		_caseBase.init(_connector);
		java.util.Collection<CBRCase> cases = _caseBase.getCases();
		for (CBRCase c: cases)
			System.out.println(c.getDescription());
		return _caseBase;
	}

	public void mainS(Osoba o,ArrayList<String>simptomi) {
		for(int i=0;i<simptomi.size();i++) {
		StandardCBRApplication recommender = new CbrApplication();
		try {
			recommender.configure();

			recommender.preCycle();

			CBRQuery query = new CBRQuery();
			
DiseaseDesc dd = new DiseaseDesc();
			
			dd.setIme(simptomi.get(0));
			if(o.getPol().equals("Male"))
				dd.setPol("musko");
			if(o.getPol().equals("Female"))
				dd.setPol("zensko");
			if(o.getGodine()<1)
				dd.setGodine("0");
			if(o.getGodine()>=1 && o.getGodine()<4)
				dd.setGodine("1-4");
			if(o.getGodine()>=5 && o.getGodine()<14)
				dd.setGodine("5-14");
			if(o.getGodine()>=15 && o.getGodine()<29)
				dd.setGodine("15-29");
			if(o.getGodine()>=30 && o.getGodine()<44)
				dd.setGodine("30-44");
			if(o.getGodine()>=45 && o.getGodine()<59)
				dd.setGodine("45-59");
			if(o.getGodine()>=60 && o.getGodine()<74)
				dd.setGodine("60-74");
			if(o.getGodine()>=75)
				dd.setGodine("75");
			dd.setRasa(o.getRasa());
			
			query.setDescription( dd );
			recommender.cycle(query);

			recommender.postCycle();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	}

}