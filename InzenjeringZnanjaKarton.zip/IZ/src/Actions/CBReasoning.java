package Actions;

import java.util.ArrayList;

import model.Osoba;

public class CBReasoning {
	
	public void Do(Osoba o,ArrayList<String>simp) {
		
	}

}
