package model;

import ucm.gaia.jcolibri.cbrcore.Attribute;
import ucm.gaia.jcolibri.cbrcore.CaseComponent;

public class DiseaseDesc implements CaseComponent{


private String godine;
private String pol;
private String simptom;
private String rasa;
private double ver;
private String ime;
public String getGodine() {
	return godine;
}



@Override
public String toString() {
	return  simptom +";"+ver;
}



public void setGodine(String godine) {
	this.godine = godine;
}
public String getPol() {
	return pol;
}
public void setPol(String pol) {
	this.pol = pol;
}
public String getSimptom() {
	return simptom;
}
public void setSimptom(String simptom) {
	this.simptom = simptom;
}
public String getRasa() {
	return rasa;
}
public void setRasa(String rasa) {
	this.rasa = rasa;
}
public double getVer() {
	return ver;
}
public void setVer(double ver) {
	this.ver = ver;
}
public String getIme() {
	return ime;
}
public void setIme(String ime) {
	this.ime = ime;
}
@Override
public Attribute getIdAttribute() {
	// TODO Auto-generated method stub
	return null;
}
	
}
